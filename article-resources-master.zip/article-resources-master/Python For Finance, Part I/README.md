This repo contains the source code for the post: [Python for Finance, Part I: Yahoo Finance API, pandas, and matplotlib](http://www.learndatasci.com/python-finance-part-yahoo-finance-api-pandas-matplotlib/)

The source code is available via both a .py script and an iPython Notebook.
